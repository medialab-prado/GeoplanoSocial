package es.geoplanosocial.games;

/**
 * Created by guzman on 21/10/2017.
 */
public interface GameCallback {
    void onCompleted();
    int getCurrentLevel();
}
